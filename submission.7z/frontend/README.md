# FPS_utep-sp17
UTEP CS4311 Spring 2017 capstone: FPS

## Organization
This directory will contain the design and implementation for the Protoype of the LegaC development team capstone project. Naming convention will be detailed soon. 